#!/usr/bin/env python3

from __future__ import annotations

import sys, time

import cultures  # noqa: E402  (the cultures file must exist before tagdb reads it)

cultures.ensure()
import religions  # noqa: E402

religions.ensure()

from tagdb import *  # noqa: F401,F403
from eu4 import *  # noqa: F401,F403
from ck3 import *  # noqa: F401,F403
from rites import step_rites
from tagloc import step_tagloc
from vanillapatch import step_vanilla_patches
from culturetitles import step_government_names


def main() -> int:
    if "--release" in sys.argv:
        import release

        return release.main([a for a in sys.argv[1:] if a != "--release"])
    started = time.time()
    print(f"Charlemagne's Legacy - full build\n{'=' * 60}")

    phases = [
        ("patch base-game files", step_vanilla_patches),
        ("check the Tag database", selfcheck),
        ("write the Christian rite schools", step_rites),
        ("lift tag names from CK3", step_tagloc),
        ("lift government titles from CK3", step_government_names),
        ("generate province files", step_provinces),
        ("generate country files", step_countries),
        ("generate the empire decision", step_hre),
        ("write starting vassals", step_diplomacy),
        ("write preset wars", step_wars),
        ("generate the Magyars", step_custom),
        ("rewrite vanilla realm colours", step_vanilla_countries),
        ("generate the restore-colours decision", step_restore_colours),
        ("write formation triggers", step_formation_triggers),
        ("filter vanilla events", step_events),
        ("filter vanilla decisions", step_filter_decisions),
        ("check CK3 rulers", step_ck3, []),
        ("check start-date ownership", step_start),
    ]

    def step(label, fn, *args):
        print(f"\n\033[1m==> {label}\033[0m", flush=True)
        try:
            return fn(*args) or 0
        except SystemExit as exc:
            return int(exc.code or 0)

    for phase in phases:
        label, fn, *rest = phase
        try:
            rc = step(label, fn, *rest)
        except Exception:
            import traceback

            traceback.print_exc()
            print(f"\n\033[31mBUILD FAILED\033[0m with an exception in {label}")
            return 1
        if rc:
            print(f"\n\033[31mBUILD FAILED\033[0m at {label}")
            return 1

    print(f"\n{'=' * 60}\n\033[32mBUILD OK\033[0m in {time.time() - started:.1f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
